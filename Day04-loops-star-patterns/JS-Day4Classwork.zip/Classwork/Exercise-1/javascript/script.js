
let num = 0;
console.log("Printing even numbers using while loop")
while (num < 50) {
    if(num%2 == 0){
    console.log(num);
    }
    num++;
  }
