let a = 2;
let b = 3;
let c = 5;
let perimeter = a + b + c;
console.log(`Perimeter of a triangle having sides of length 2, 3, and 5 units is ${perimeter}`);