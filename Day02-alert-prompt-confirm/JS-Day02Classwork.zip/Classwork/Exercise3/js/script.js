let l = parseInt(prompt('Enter the length of a rectangle'))
console.log('Length of rectangle is :' + l);
let w = parseInt(prompt('Enter the length of a rectangle'))
console.log('Width of rectangle is :' + w);
console.log('Area of rectangle is ' + (l*w));
console.log('Perimeter of rectangle is ' + ((l+w)*2));