let radius = parseInt(prompt('Enetr the radius of a circle'));
console.log(`Circumference of a circle with radius ${radius} is ` + (2 * 3.14 * radius));