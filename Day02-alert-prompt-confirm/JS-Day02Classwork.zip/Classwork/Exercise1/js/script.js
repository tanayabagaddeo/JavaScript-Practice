let engMarks = 86;
let mathsMarks = 90;
let scinMarks = 75;
let average = ((engMarks + mathsMarks + scinMarks)/3 );
console.log('Average of english, maths and science marks is ' + average);