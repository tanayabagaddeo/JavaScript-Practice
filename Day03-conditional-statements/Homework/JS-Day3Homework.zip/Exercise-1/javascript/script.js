let a = 55;
let b = 70;

// if(a < 50 && a < b){
//     console.log("both the conditions 'a < 50' and 'a < b' are true.")
// }else{
//     console.log("both the conditions 'a < 50' and 'a < b' are false.")
// }

if(a<50){
    console.log("condition 'a < 50' is true.")
}else if (a<b){
    console.log("condition 'a < b' is true.")
}