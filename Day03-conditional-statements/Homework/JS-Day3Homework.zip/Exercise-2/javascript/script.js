let a = 55;
let b = 70;

if(a<50 || a<b){
    console.log("at least one of the conditions 'a < 50' or 'a < b' is true.");
}else{
    console.log("both the consitions 'a < 50' and 'a < b' are false");
}