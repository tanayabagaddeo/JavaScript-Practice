let num1 = parseInt(prompt('Enter number 1'));
let num2 = parseInt(prompt('Enter number 2'));

if(num1>num2){
    console.log(num1 + " is largest");
}else{
    console.log(num2 + " is largest");
}
