let num = parseInt(prompt('Enter a number'));


if(num>0){
    console.log(num + " is positive");
}else{
    console.log(num + " is negative");
}
