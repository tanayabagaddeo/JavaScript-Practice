// Function declaration

let element = document.getElementById('demo');
// // <h1 id="demo"></h1>

// function greet(name) {
//   element.innerText = `Welcome ${name}`;
//   // <h1 id="demo">Welcome Alice</h1>
// }

// // self-invoke
// greet('Alice');

// function fun() {
//   element.innerHTML = `<u>JavaScript is fun to learn.</u>`;
// }

// // self invoke
// fun();


// function expression

let numberOne = parseInt(prompt("Enter number one"));
let numberTwo = parseInt(prompt("Enter number two"));

// let add = function (numOne, numTwo) {
//   let sum = 0;
//   let odd = 0;

//   for (let count = numOne; count <= numTwo; count++) {
//     if (count % 2 === 0) {
//       sum += count;
//     } else {
//       odd += count;
//     }

//     element.innerHTML = `Addition of even number from ${numOne} to ${numTwo} is ${sum} <br/>`;
//     element.innerHTML += `Addition of odd number from ${numOne} to ${numTwo} is ${odd}`;
//   }
// };

// add(numberOne, numberTwo);

// Arrow function

// let multiplication = (numOne, numTwo) => {
//   return numOne * numTwo;
// };

// let multiplication = (numOne, numTwo) => numOne * numTwo;

// let result = multiplication(numberOne, numberTwo);

// element.innerText = `Multiplication of ${numberOne} and ${numberTwo} is ${result}`;

// pi * r * r 

// let areaOfCircle = radius => 3.142 * radius * radius

// console.log(areaOfCircle(2))

// IIFE

// (function (numOne, numTwo) {
//   element.innerText = numOne + numTwo;
// })(numberOne, numberTwo);


(function greet() {
  element.innerText = 'Welcome';
})();


// (function (formalParameter) {

// })(actualParameter)