// Write a program to print your name using a function.

function MyName(){
  document.getElementById("my-name").innerText = "Tanaya Bagaddeo";
  console.log("Tanaya Bagaddeo");
}
MyName();